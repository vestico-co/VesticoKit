//
//  vestico_kit.h
//  vestico-kit
//
//  Created by Oliver Bevan on 15/07/2022.
//  Copyright © 2022 Vestico Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for vestico_kit.
FOUNDATION_EXPORT double vestico_kitVersionNumber;

//! Project version string for vestico_kit.
FOUNDATION_EXPORT const unsigned char vestico_kitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <vestico_kit/PublicHeader.h>


