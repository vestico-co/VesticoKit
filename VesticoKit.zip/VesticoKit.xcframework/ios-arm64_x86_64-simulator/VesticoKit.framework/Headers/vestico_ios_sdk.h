//
//  vestico_ios_sdk.h
//  vestico-ios-sdk
//
//  Created by Oliver Bevan on 15/07/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for vestico_ios_sdk.
FOUNDATION_EXPORT double vestico_ios_sdkVersionNumber;

//! Project version string for vestico_ios_sdk.
FOUNDATION_EXPORT const unsigned char vestico_ios_sdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <vestico_kit/PublicHeader.h>


